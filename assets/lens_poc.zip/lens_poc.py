from pathlib import Path
import zipfile

out = Path("/mnt/data/lens_poc")
script_text = In[-1] if "In" in globals() and In[-1] else ""
# The previous visible cell contains the complete POC source.
(out / "lens_poc.py").write_text(script_text, encoding="utf-8")

zip_path = Path("/mnt/data/lens_poc.zip")
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
    for path in sorted(out.iterdir()):
        zf.write(path, arcname=path.name)

print(f"Updated runnable source and rebuilt {zip_path}")